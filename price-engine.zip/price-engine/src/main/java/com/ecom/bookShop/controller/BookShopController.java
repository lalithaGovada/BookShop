package com.ecom.bookShop.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ecom.bookShop.dto.BookInfo;
import com.ecom.bookShop.dto.Checkout;
import com.ecom.bookShop.exception.InternalServerError;
import com.ecom.bookShop.service.BookShopService;

@RestController
public class BookShopController {

	public static final Logger logger = LoggerFactory.getLogger(BookShopController.class);
	
    @Autowired
    BookShopService bookService;

    @RequestMapping(method = RequestMethod.GET, value = "/getPrice", produces = MediaType.APPLICATION_JSON_VALUE)
    public String getPrice(@RequestParam(name="title") String name){
    	try {
    		return new ResponseEntity<String>(bookService.getPrice(name), HttpStatus.OK).getBody();
    	}catch (Exception e) {
    		BookShopController.logger.info("Get product Price");
    		throw new InternalServerError(e.getMessage());
    	}
    }
    
    @RequestMapping(method = RequestMethod.POST, value = "/checkout", produces = MediaType.APPLICATION_JSON_VALUE)
    public Checkout checkOut(@RequestBody List<BookInfo> cart){
    	try {
    		return new ResponseEntity<Checkout>(bookService.checkOut(cart), HttpStatus.OK).getBody();
    	}catch (Exception e) {
    		BookShopController.logger.info("Checkout the selected product added to cart and returns the bill amount");
    		throw new InternalServerError(e.getMessage());
    	}
    }
}
