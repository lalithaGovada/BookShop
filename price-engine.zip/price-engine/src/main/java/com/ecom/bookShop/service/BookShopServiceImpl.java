package com.ecom.bookShop.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

import com.ecom.bookShop.dto.BookInfo;
import com.ecom.bookShop.dto.Checkout;

@Service
public class BookShopServiceImpl implements BookShopService{

	private final String rules= "/rule/rule.json";
	private final String products= "/rule/products.json";
	
	@Override
	public String getPrice(String productName) throws IOException {
		Reader reader = new InputStreamReader(BookShopServiceImpl.class.getResourceAsStream(products));
		try (BufferedReader re = new BufferedReader(reader)) {
			StringBuilder buf = new StringBuilder();
			String line;
			while ((line = re.readLine()) != null)
				buf = buf.append(line);
			JSONObject obj = new JSONObject(buf.toString());
			JSONArray productArray = obj.getJSONArray("products");
			for (int i = 0 ; i < productArray.length(); i++) {
				JSONObject product = productArray.getJSONObject(i);
				if(!productName.isEmpty() && productName.equals(product.get("title"))) {
					return (String) "£"+product.get("price");
				}else {
					return "Book not available, try another !!";
				}
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return "£0.0";
	}

	@Override
	public Checkout checkOut(List<BookInfo> cart) throws IOException{
		Reader ruleReader = new InputStreamReader(BookShopServiceImpl.class.getResourceAsStream(rules));
		Checkout checkOut = new Checkout();
		JSONArray ruleArray = new JSONArray();
		double totalPrice = 0;
		double totalDiscount = 0;
		try (BufferedReader re = new BufferedReader(ruleReader)) { 
			StringBuilder buf = new StringBuilder();
			String line;
			
			while ((line = re.readLine()) != null)
				buf = buf.append(line);
			
			ruleArray = new JSONObject(buf.toString()).getJSONArray("rules");
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		for (int i = 0 ; i < ruleArray.length() ; i++) { 
			JSONObject rule = ruleArray.getJSONObject(i);
			for (BookInfo cartInfo : cart) {
				double discount = 0;
				if("direct_discount_published_year".equals(rule.get("type")) && cartInfo.getPublishedOn() > 2000) {
					discount = (cartInfo.getPrice() * (rule.getDouble("discount")/100));
					totalDiscount += discount;
					totalPrice += cartInfo.getPrice() - discount;
				}else {
					if("direct_discount_greater_30".equals(rule.get("type"))) {
						break;
					}
					totalPrice = (totalPrice + cartInfo.getPrice());
				}
			}
			if("direct_discount_greater_30".equals(rule.get("type")) && totalPrice > 30) {
				totalDiscount +=  totalPrice * (rule.getDouble("discount")/100);
				break;
			}
		}
		
		checkOut.setBookInfo(cart);
		checkOut.setTotalDiscount(Math.round(totalDiscount));
		checkOut.setTotalPrice(Math.round(totalPrice));
		checkOut.setTotalPriceAfterDisc(Math.round(totalPrice - totalDiscount));
		
		return checkOut;
	}
}
