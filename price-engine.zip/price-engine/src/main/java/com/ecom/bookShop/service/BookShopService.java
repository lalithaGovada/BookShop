package com.ecom.bookShop.service;

import java.io.IOException;
import java.util.List;

import org.springframework.stereotype.Service;

import com.ecom.bookShop.dto.BookInfo;
import com.ecom.bookShop.dto.Checkout;

@Service
public interface BookShopService {
	public String getPrice (String productName) throws IOException; 
	public Checkout checkOut (List<BookInfo> cart) throws IOException;
}
