package com.ecom.bookShop.dto;

import java.io.Serializable;
import java.util.List;

public class Checkout implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private List<BookInfo> bookInfo;
	private double totalDiscount;
	private double totalPrice;
	private double totalPriceAfterDisc;
	
	public List<BookInfo> getBookInfo() {
		return bookInfo;
	}
	public void setBookInfo(List<BookInfo> bookInfo) {
		this.bookInfo = bookInfo;
	}
	public double getTotalDiscount() {
		return totalDiscount;
	}
	public void setTotalDiscount(double totalDiscount) {
		this.totalDiscount = totalDiscount;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public double getTotalPriceAfterDisc() {
		return totalPriceAfterDisc;
	}
	public void setTotalPriceAfterDisc(double totalPriceAfterDisc) {
		this.totalPriceAfterDisc = totalPriceAfterDisc;
	}
}
