package com.ecom.bookShop.dto;

import java.io.Serializable;

public class BookInfo implements Serializable{
    
	private String title;    
    private double price;
    private Integer publishedOn;
    
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Integer getPublishedOn() {
		return publishedOn;
	}
	public void setPublishedOn(Integer publishedOn) {
		this.publishedOn = publishedOn;
	}
	public BookInfo(String title, double price, Integer publishedOn) {
		super();
		this.title = title;
		this.price = price;
		this.publishedOn = publishedOn;
	}
}
