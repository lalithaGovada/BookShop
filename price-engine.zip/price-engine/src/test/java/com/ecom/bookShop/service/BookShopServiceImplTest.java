package com.ecom.bookShop.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.ecom.bookShop.dto.BookInfo;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {BookShopServiceImpl.class, BookShopService.class})
public class BookShopServiceImplTest {
	
	BookShopServiceImpl bookService = new BookShopServiceImpl();
	
	@Test
	void getPriceTest() throws IOException {
		Assert.assertEquals("£15.20", bookService.getPrice("Moby Dick"));
	}
	
	@Test
	void getPriceNotEqualsTest() throws IOException {
		List<BookInfo> cart = createCart();
		Assert.assertNotEquals(bookService.getPrice(cart.get(0).getTitle()), "£20.65");
	}
	
	@Test
	void checkOutGetTotalCostTest() throws IOException {
		List<BookInfo> cart = createCart();
		Assert.assertEquals(bookService.checkOut(cart).getTotalPrice(), 32.0);
	}
	
	@Test
	void checkOutGetTotalDiscountTest() throws IOException {
		List<BookInfo> cart = createCart();
		Assert.assertEquals(bookService.checkOut(cart).getTotalDiscount(), 2.0);
	}
	
	@Test
	void checkOutGetTotalPriceAfterDiscountTest() throws IOException {
		List<BookInfo> cart = createCart();
		Assert.assertEquals(bookService.checkOut(cart).getTotalPriceAfterDisc(), 30.0);
	}
	
	@Test
	void checkOutGetTotalCostNotEqualsTest() throws IOException {
		List<BookInfo> cart = createCart();
		Assert.assertNotEquals(bookService.checkOut(cart).getTotalPrice(), "23.0");
	}
	
	@Test
	void checkOutGetTotalDiscountNotEqualsTest() throws IOException {
		List<BookInfo> cart = createCart();
		Assert.assertNotEquals(bookService.checkOut(cart).getTotalDiscount(), "12.0");
	}
	
	@Test
	void checkOutGetTotalPriceAfterDiscountNotEqualsTest() throws IOException {
		List<BookInfo> cart = createCart();
		Assert.assertNotEquals(bookService.checkOut(cart).getTotalPriceAfterDisc(), "34.0");
	}

	private List<BookInfo> createCart() {
		List<BookInfo> products = new ArrayList<>();
		products.add(new BookInfo("Moby Dick", 20.45, 1825));
		products.add(new BookInfo("The Terrible Privacy of Maxwell Sim", 11.56, 1854));
		return products;
	}
}
