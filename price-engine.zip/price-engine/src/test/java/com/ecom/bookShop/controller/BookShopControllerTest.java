package com.ecom.bookShop.controller;


import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.testng.Assert;

import com.fasterxml.jackson.databind.ObjectMapper;

@WebMvcTest(value = BookShopController.class)
@RunWith(SpringRunner.class)
public class BookShopControllerTest {

	@Autowired
	private WebApplicationContext webApplicationContext;
	
	@Autowired
	private MockMvc mockMvc;
	
	@Before
	public void setUp() {
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
	}
	
	@Test
	public void getPriceTest() throws Exception {
		MvcResult mvcResult = mockMvc
				.perform(get("/getPrice").contentType(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		String content = mvcResult.getResponse().getContentAsString();
		String result = new ObjectMapper().readValue(content, String.class);
		Assert.assertEquals(200, mvcResult.getResponse().getStatus());
		if (result != null) {
			assert (result != null);
		}
	}
	
	@Test
	public void checkOutTest() throws Exception {
		String request = "[\r\n"
				+ "    {\r\n"
				+ "        \"title\" : \"Moby Dick\",\r\n"
				+ "        \"price\" : 20.45,\r\n"
				+ "        \"publishedOn\" : 1825\r\n"
				+ "    },\r\n"
				+ "    {\r\n"
				+ "        \"title\" : \"The Terrible Privacy of Maxwell Sim\",\r\n"
				+ "        \"price\" : 11.56,\r\n"
				+ "        \"publishedOn\" : 1854\r\n"
				+ "    }\r\n"
				+ "]";
		MockMvcRequestBuilders.post("/checkout").accept(MediaType.APPLICATION_JSON).content(request)
		.contentType(MediaType.APPLICATION_JSON);

		MvcResult mvcResult = mockMvc.perform(
											MockMvcRequestBuilders.post("/checkout")
											.accept(MediaType.APPLICATION_JSON).content(request)
											.contentType(MediaType.APPLICATION_JSON)
											).andReturn();
				
		int status = mvcResult.getResponse().getStatus();
		Assert.assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		if (content != null) {
			assert (content != null);
		}
	}
}
